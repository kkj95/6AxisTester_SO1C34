﻿using Dln.I2cMaster;
using FZ4P.DriverIc.I2CBase;
using FZ4P.DriverIc.I2CBase.Interfaces;
using FZ4P.DriverIc.Interfaces;
using FZ4P.DriverIc.OISIC.Base;
using MathNet.Numerics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace FZ4P.DriverIc.OISIC
{
    /// <summary>
    /// IC 동작에 구현체 
    /// </summary>
    //동윤보드 14bit Move 동작
    public class DW9836N : DriveICBase,IOISFunction, IFRAFunction
    {
        private object _lock = new object();
        private readonly IOneTwoBytesDrivingIC _controls;
        private CalculatorDW9836 cal = new CalculatorDW9836(160);           //160mA 세팅으로 되어있다고 하여 고정함.

        public int FRA_Addr { get; set; } = 0x12;
        public int OISX_Addr { get; set; } = 0x0E;
        public int OISY_Addr { get; set; } = 0x4E;
        public int OIS_MIN_CODE { get; set; } = 0;
        public int OIS_MID_CODE { get; set; } = 8192;
        public int OIS_MAX_CODE { get; set; } = 16384;

        //public int OIS_MIN_CODE { get; set; } = 0;
        //public int OIS_MID_CODE { get; set; } = 2048;
        //public int OIS_MAX_CODE { get; set; } = 4095;

        public IOneTwoBytesDrivingIC Controls => _controls;

        public DW9836N(IOneTwoBytesDrivingIC controls)
        {
            _controls = controls;
        }
        public void OISMove(int ch, int Xcode, int Ycode)
        {
            var moveX = Xcode << 2;
            var moveY = Ycode << 2;

            var targetBufferX1 = (moveX >> 8) & 0xFF;
            var targetBufferX2= (moveX) & 0xFF;

            var targetBufferY1 = (moveY >> 8) & 0xFF;
            var targetBufferY2 = (moveY) & 0xFF;

            Controls.WriteByte(OISX_Addr, (int)RegisterMapDW9836N.Target, 1, (byte)targetBufferX1);
            Controls.WriteByte(OISX_Addr, (int)RegisterMapDW9836N.Target1, 1, (byte)targetBufferX2);

            Controls.WriteByte(OISY_Addr, (int)RegisterMapDW9836N.Target, 1, (byte)targetBufferY1);
            Controls.WriteByte(OISY_Addr, (int)RegisterMapDW9836N.Target1, 1, (byte)targetBufferY2);
        }

        public void OISMoveOL(int ch, int axis, int code)
        {
            if (code < 0) code = 0;
            if (code > 0x1FFF) code = 0x1FFF; // 8191

            ushort raw = (ushort)(code << 3);

            byte data1 = (byte)((raw >> 8) & 0xFF);
            byte data2 = (byte)(raw & 0xFF);

            Controls.WriteByte(OISX_Addr, (int)RegisterMapDW9836N.Target, 1, data1);
            Controls.WriteByte(OISX_Addr, (int)RegisterMapDW9836N.Target1, 1, data2);

           
        }

        public void OISOnOff(int ch, bool isOn)
        {
            //임시
            var axisTypeX = AxisTypeDW.AxisX;
            var axisTypeY = AxisTypeDW.AxisY;

            if (isOn)
            {
                SetOperationMode(axisTypeX, OperationTypeDW.StandbyMode);
                SetOperationMode(axisTypeX, OperationTypeDW.ClosedMode);

                SetOperationMode(axisTypeY, OperationTypeDW.StandbyMode);
                SetOperationMode(axisTypeY, OperationTypeDW.ClosedMode);
            }
            else
            {
                SetOperationMode(axisTypeX, OperationTypeDW.StandbyMode);
                SetOperationMode(axisTypeY, OperationTypeDW.StandbyMode);
            }
        }

        public void OISICReset(int ch)
        {
            throw new NotImplementedException();
        }

        public bool OIS_StausCheck(int ch, byte res1, byte res2)
        {
            throw new NotImplementedException();
        }

        public bool OIS_StausCheck(int ch, int memAddr, byte res1, byte res2)
        {
            throw new NotImplementedException();
        }

        public short ReadOISHall(int ch, int axis, int mode)
        {
            short ReadData = 0x0000;

            int SlaveID = GetAxisTypeID((AxisTypeDW)axis);

            var Wrod = Controls.Read2Byte(SlaveID, (int)RegisterMapDW9836N.POSITION_READ_LOW, 1);

            ReadData = (short)(Wrod >> 2);
            
            return (short)ReadData;
        }

        public bool SetManualDrvModeXY(int ch, int MidCodeX, int MidCodeY)
        {
            bool flag = false;
            OISMove(ch, MidCodeX, MidCodeY);

            return true;
        }

        //가이드 된 시퀀스  
        public bool SetStore(int axis)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);
            bool bResult = true;
            try
            {
                Controls.WriteByte(slaveID, (int)0x28, 1, (byte)0x39);
                Controls.WriteByte(slaveID, (int)0x28, 1, (byte)0xA0);
                Thread.Sleep(50);
                Controls.WriteByte(slaveID, (int)RegisterMapDW9836N.STORE_PROD_ID, 1, (byte)0x01);
                Thread.Sleep(640);
                Controls.WriteByte(slaveID, (int)0x28, 1, (byte)0x14);
                Thread.Sleep(50);
                Controls.WriteByte(slaveID, (int)RegisterMapDW9836N.SWREST, 1, (byte)0x01);
                Thread.Sleep(50);
            }
            catch
            {
                bResult = false;
            }

            return bResult;
        }

        //현재 개발중이라 시퀀스가 달라질수 있음... 그래서 스토어 시퀀스가 두개로 나뉨... 
        public bool TestSetStore(int axis)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);
            bool bResult = true;
            try
            {
                Controls.WriteByte(slaveID, (int)RegisterMapDW9836N.STORE_PROD_ID, 1, (byte)0x01);
                Thread.Sleep(640);
            }
            catch
            {
                bResult = false;
            }

            return bResult;
        }

        public double GetCurrent(int axis)
        {
            short ReadData = 0x0000;
            int SlaveID = GetAxisTypeID((AxisTypeDW)axis);
            var Wrod = Controls.Read2Byte(SlaveID, (int)RegisterMapDW9836N.IOUT_CURRENT_LOW, 1);
            ReadData = (short)(Wrod >> 3);

            double readCurrent = Math.Abs(cal.CalculatorCurrent(ReadData));
            return readCurrent.Round(2);
        }

        public string Check_Byte(int ch, byte start, byte end)
        {
            var SlaveID = GetAxisTypeID(AxisTypeDW.AxisX);
            int addr = 0; int index = 0;
            string tmpID = string.Empty;
            byte rbuf = 0x00;
            tmpID += $"0x{start.ToString("X2")}~0x{end.ToString("X2")} : ";

            for (addr = start, index = 0; addr <= end; addr++, index++)
            {
                rbuf = _controls.ReadByte(SlaveID, addr, 1);
                if ((index & 0x0003) == 0x0000)
                    tmpID += " ";
                tmpID += rbuf.ToString("X2");

            }

            return tmpID;
        }

        /// <summary>
        /// 기본 close 모드
        /// </summary>
        /// <param name="axisType"></param>
        /// <param name="ModeType"></param>
        /// 
        public void SetOperationMode(AxisTypeDW axisType, OperationTypeDW ModeType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            byte writeData = 0x00;
            switch (ModeType)
            {
                case OperationTypeDW.StandbyMode:
                    writeData = 0x40;
                    break;
                case OperationTypeDW.SleepMode:
                    writeData = 0x20;
                    break;
                case OperationTypeDW.ClosedMode:
                    writeData = 0x00;
                    break;
                case OperationTypeDW.OpenMode:
                    writeData = 0x03;
                    break;
                default:
                    writeData = 0x00;
                    break;
            }

            Controls.WriteByte(SlaveID, (int)RegisterMapDW9836N.Mode, 1, writeData);
        }

        public void SetRegisterI3CMode(AxisTypeDW axisType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            Controls.WriteByte(SlaveID, 0x7F, 1, 0x10);
            Controls.WriteByte(SlaveID, 0x7C, 1, 0x0C);
            Controls.WriteByte(SlaveID, (int)RegisterMapDW9836N.STORE_PROD_ID, 1, 0x01);
        }
        public void SetRegisterI2CMode(AxisTypeDW axisType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            Controls.WriteByte(SlaveID, 0x7F, 1, 0x00);
            Controls.WriteByte(SlaveID, 0x7C, 1, 0x04);
            Controls.WriteByte(SlaveID, (int)RegisterMapDW9836N.STORE_PROD_ID, 1, 0x01);
        }
        public byte ReadRegisterPIDH503(AxisTypeDW axisType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            return Controls.ReadByte(SlaveID, 0x7E, 1);
        }
        public byte ReadRegisterPIDH5032(AxisTypeDW axisType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            return Controls.ReadByte(SlaveID, 0x4D, 1);
        }
        public byte ReadRegisterPIDH5033(AxisTypeDW axisType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            return Controls.ReadByte(SlaveID, 0x4A, 1);
        }
        public byte ReadTest(AxisTypeDW axisType)
        {
            int SlaveID = GetAxisTypeID(axisType);
            return Controls.ReadByte(SlaveID, 0x4B, 1);
        }
        public byte LoopWrite(AxisTypeDW axisType,bool onoff)
        {
            int SlaveID = GetAxisTypeID(axisType);
            if (onoff)
                Controls.WriteByte(SlaveID, 0x4B, 1, 0x03); 
            else
                Controls.WriteByte(SlaveID, 0x4B, 1, 0x00);

            Thread.Sleep(50);
            return Controls.ReadByte(SlaveID, 0x4B, 1);
        }
        private int GetAxisTypeID(AxisTypeDW axisType)
        {
            int SlaveID = -1;
            switch (axisType)
            {
                case AxisTypeDW.AxisX:
                    SlaveID = OISX_Addr;
                    break;
                case AxisTypeDW.AxisY:
                    SlaveID = OISY_Addr;
                    break;
                case AxisTypeDW.AxisZ:
                    SlaveID = FRA_Addr;
                    break;
                default:
                    throw new Exception("Type Not Difined Error");
            }

            return SlaveID;
        }

        public void OISReset(int ch, int axis, bool OnOff)
        {
            byte data = 0x00;
            if (OnOff)
                data = 0x10;
            int slaveID = GetAxisTypeID((AxisTypeDW)axis);
            _controls.WriteByte(slaveID, (int)RegisterMapDW9836N.STORE_PROD_ID, 1, data);
        }

        //PT 
        /// <summary>
        /// 
        /// </summary>
        /// <param name="axis"></param>
        /// <param name="OnOff">Off 는 Act 설정 파일을 쓸수있게 하는 상태. On은 Act 설정 파일을 쓸수 없게 하는 상태</param>
        public void Set_PT(int axis,bool OnOff)
        {
            var SlaveID = GetAxisTypeID((AxisTypeDW)axis);

            if (!OnOff)
            {
                _controls.WriteByte(SlaveID, 0x28, 1, 0x39);
                _controls.WriteByte(SlaveID, 0x28, 1, 0xA0);
            }
            else
            {
                _controls.WriteByte(SlaveID, 0x28, 1, 0x14);
            }
        }

        public List<int> LiearCompRead(int axis)
        {
            List<int> reulst = new List<int>();
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);

            int startAddress = 0x55;

            for (int i = 0; i < 16; i++)
            {
                reulst.Add(_controls.ReadByte(slaveID, startAddress++, 1));
            }        

            return reulst;
        }

        public void LiearCompWrite(int axis, List<int> CompValue)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);
            Set_PT(axis, false);

            Thread.Sleep(10);
            int startAddress = 0x55;
            _controls.WriteByte(slaveID, startAddress++, 1, 0x01);        // Linearity Enabled

            CompValue.ForEach(vlaue =>
            {
                _controls.WriteByte(slaveID, startAddress++, 1, (byte)vlaue);
            });
        }

        public void LiearCompClearWrite(int axis)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);
            Set_PT(axis, false);

            int startAddress = 0x55;
            _controls.WriteByte(slaveID, startAddress, 1, 0x00);        // Linearity Enabled
        }

        public byte LiearCompEnable(int axis,bool onOff)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);

            if ((AxisTypeDW)axis == AxisTypeDW.AxisY)
                Set_PT((int)AxisTypeDW.AxisX, false);
            Set_PT(axis, false);

            int startAddress = 0x55;
            if (onOff)
            {
                _controls.WriteByte(slaveID, startAddress, 1, 0x01);        // Linearity Enabled
                Thread.Sleep(50);
                //TestSetStore(axis);
                if ((AxisTypeDW)axis == AxisTypeDW.AxisY)
                    Set_PT((int)AxisTypeDW.AxisX, true);
                Set_PT(axis, true);
                Thread.Sleep(50);
                return _controls.ReadByte(slaveID, startAddress, 1);
            }
            else
            {
                _controls.WriteByte(slaveID, startAddress, 1, 0x00);        // Linearity Disabled
                Thread.Sleep(50);
                //TestSetStore(axis);
                if ((AxisTypeDW)axis == AxisTypeDW.AxisY)
                    Set_PT((int)AxisTypeDW.AxisX, true);
                Set_PT(axis, true);
                Thread.Sleep(50);
                return _controls.ReadByte(slaveID, startAddress, 1);
            }
        }

        public void SetPCAL(int axis,int code)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);
            _controls.WriteByte(slaveID, (int)RegisterMapPIDDW9836N.PCAL, 1, (byte)code);
        }
        public void SetNCAL(int axis, int code)
        {
            var slaveID = GetAxisTypeID((AxisTypeDW)axis);
            _controls.WriteByte(slaveID, (int)RegisterMapPIDDW9836N.NCAL, 1, (byte)code);
        }


        public void FRA_Echoboard_StartStop(int ch, StartStopType iStep)
        {
            var slaveID = GetAxisTypeID(AxisTypeDW.AxisZ);

            if (iStep == StartStopType.Stop)
                _controls.WriteByte(slaveID, (int)RegisterMapFRA.FRA_START, 1, 0x00 ); //stop            
            else if (iStep == StartStopType.Start)
                _controls.WriteByte(slaveID, (int)RegisterMapFRA.FRA_START, 1, 0x03 ); //start
            else if (iStep == StartStopType.Ready)
                _controls.WriteByte(slaveID, (int)RegisterMapFRA.FRA_START, 1, 0x01); //Ready
        }
        public void AMA_Echoboard_StartStop(int ch, StartStopType iStep)
        {
            var slaveID = GetAxisTypeID(AxisTypeDW.AxisZ);

            if (iStep == StartStopType.Stop)
                _controls.WriteByte(slaveID, (int)RegisterMapAMA.AMA_START, 1, 0x00); //stop            
            else if (iStep == StartStopType.Start)
                _controls.WriteByte(slaveID, (int)RegisterMapAMA.AMA_START, 1, 0x03); //start
            else if (iStep == StartStopType.Ready)
                _controls.WriteByte(slaveID, (int)RegisterMapAMA.AMA_START, 1, 0x01); //Ready
        }


        public bool Echo_Board_WhoAmI(int ch)
        {
            byte[] board_info = new byte[1];
            var SlaveID = GetAxisTypeID(AxisTypeDW.AxisZ);

            board_info[0] = _controls.ReadByte(SlaveID, (int)RegisterMapFRA.BOARD_INFO, 1); 

            if (board_info[0] != 0xAE)
            {
                return false;
            }
            return true;
        }

        public void Echo_Board_SetParameter(Echo_ParamBase param)
        {
            //기능에 따라 분리가 필요할수도 있겠다. - 추후 펙토리로 빼서 else if 제거 <-FRA PM GM 세팅로직도 여기에 추가하기 위함.
            if (param is AMA_TestSetting_Params parmas)
            {
                //var executor = new Echo_AMA_ParamSet(parmas, _controls, FRA_Addr);
                //executor.SetParam();
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        public void Echo_Board_Select_Ch(int ch)
        {
            if(ch == 1)
                _controls.WriteByte(FRA_Addr, (int)RegisterMapFRA.I2C_CH, 1, 0x01);
            else if(ch == 2)
                _controls.WriteByte(FRA_Addr, (int)RegisterMapFRA.I2C_CH, 1, 0x02);
            else
                _controls.WriteByte(FRA_Addr, (int)RegisterMapFRA.I2C_CH, 1, 0x01);
        }

        public byte ReadAddress(AxisTypeDW axisType,int RegisterAddress)
        {
            var slaveID = GetAxisTypeID(axisType);
            return _controls.ReadByte(slaveID, RegisterAddress, 1); 
        }

        public void Set_FRA_I2C_Speed()
        {
            //var slaveID = GetAxisTypeID(AxisTypeDW.AxisX);
            _controls.WriteByte(FRA_Addr, (int)RegisterMapFRA.FRA_I2C_SPEED, 1, 0x11);
        }

        public void Set_Control_Freq(ControlFreqMode controlFreqMode)
        {
            byte byData = 0x00;
            var slaveID = GetAxisTypeID(AxisTypeDW.AxisX);
            
            if (controlFreqMode == ControlFreqMode.Freq5KHz)
                byData = 0x00;
            else if (controlFreqMode == ControlFreqMode.Freq10KHz)
                byData = 0x01;
            else if (controlFreqMode == ControlFreqMode.Freq15KHz)
                byData = 0x0B;
            _controls.WriteByte(FRA_Addr, (int)RegisterMapFRA.CONTROL_FREQ, 1, byData);
        }


        //public void SetI3CByPaaMode(bool Onoff)
        //{
        //    int slaveId = GetAxisTypeID(AxisTypeDW.AxisY);
        //    if(Onoff)
        //        _controls.WriteByte(slaveId,0xE6,1,0x01);
        //    else
        //        _controls.WriteByte(slaveId, 0xE6, 1, 0x00);
        //}

        //public void SetH503WakeUp()
        //{
        //    int slaveId = GetAxisTypeID(AxisTypeDW.AxisY);
        //    _controls.WriteByte(slaveId, 0x00, 1, 0x00);
        //}

        //public short GetI3CData(AxisTypeDW axisTypeDW)
        //{
        //    int slaveId = GetAxisTypeID(axisTypeDW);
        //    var v1 = _controls.Read2Byte(slaveId, 0x40, 1);
        //    var v2 = _controls.Read2Byte(slaveId, 0x42, 1);

        //    var ReadData = (short)(v1);

        //    return (short)ReadData;
        //}
    }
}
